# Fantasy Football ML

Config-driven fantasy football engine for **Sleeper** and **ESPN**, defaulting to
**full PPR** but editable in one file. This is the data + scoring foundation; the
projection models and lineup optimizer plug in on top of it.

## What's here

```
ff_ml/
├── config/
│   └── scoring.yaml          # ← EDIT THIS when league rules change
├── ff_ml/
│   ├── scoring.py            # config-driven scoring engine
│   ├── data/
│   │   ├── historical.py     # pulls real player-week data (nflreadpy)
│   │   └── features.py       # lagged/rolling features + walk-forward split
│   └── platforms/
│       ├── base.py           # common interface (Sleeper & ESPN share it)
│       ├── sleeper.py        # free, no-auth API + trending waivers
│       └── espn.py           # public or private (cookie) leagues
├── scripts/demo.py           # end-to-end runnable demo
└── requirements.txt
```

## Setup

```bash
pip install -r requirements.txt
python -m scripts.demo          # pulls real data and runs the whole flow
```

## Changing scoring (the editable part)

Everything downstream reads `config/scoring.yaml`. To switch PPR formats, change
one number:

```yaml
receptions: { stat: receptions, points: 1.0 }   # 1.0 full / 0.5 half / 0.0 standard
```

Add bonuses, tweak TD values, flip interceptions to -1 — the historical labels,
projections, and optimizer all recompute on the next run. Unknown columns are
ignored with a warning, so a typo won't silently corrupt your scores.

### Auto-sync scoring from your actual league

Instead of editing by hand, pull your league's real settings:

```python
from ff_ml.platforms.sleeper import SleeperPlatform
cfg = SleeperPlatform(league_id="YOUR_ID", season=2025).import_scoring()
cfg.save("config/scoring.yaml")     # now your config matches your league exactly
```

```python
from ff_ml.platforms.espn import ESPNPlatform
espn = ESPNPlatform(league_id="YOUR_ID", season=2025,
                    espn_s2="...", swid="...")   # cookies only for private leagues
espn.import_scoring().save("config/scoring.yaml")
```

## Connecting a league

**Sleeper** (free, no auth). Your `league_id` is in the league URL.

```python
s = SleeperPlatform(league_id="YOUR_ID", season=2025)
state = s.get_league_state()          # rosters + teams
adds  = s.trending("add", hours=24)   # waiver signal: most-added players
fa    = s.get_free_agents()
```

**ESPN.** Public leagues need nothing extra. Private leagues need your
`espn_s2` and `swid` browser cookies (they stay on your machine).

```python
e = ESPNPlatform(league_id="YOUR_ID", season=2025, espn_s2="...", swid="...")
state = e.get_league_state()
fa    = e.get_free_agents()
```

## Design notes

- **Two problems, cleanly separated.** Prediction (project points) feeds
  decision (draft / waiver / lineup). Scoring is the shared contract between them.
- **Leakage safety is built in.** Features for week *t* use only weeks *< t*
  (lagged/rolling with a shift); evaluation is walk-forward, never random k-fold.
- **Data source:** `nflreadpy`, the maintained successor to the now-deprecated
  `nfl_data_py`.

## Next steps (not yet built)

1. **Projections** — gradient boosting baseline + hierarchical Bayesian model
   that outputs a *distribution* per player-week (floor/ceiling, not just a mean).
2. **Lineup optimizer** — integer program over roster slots; with the Bayesian
   posterior, do mean-variance / CVaR to chase ceiling or protect floor by matchup.
3. **Draft & waivers** — VORP over projections; expected-value waiver claims
   under a FAAB budget.
