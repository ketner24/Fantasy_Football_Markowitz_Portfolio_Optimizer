"""Fantasy Football ML — config-driven, multi-platform (Sleeper + ESPN)."""
