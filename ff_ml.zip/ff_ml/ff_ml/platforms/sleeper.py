"""
Sleeper connector.  Sleeper's read API is free and needs no auth or API key.

Base URL: https://api.sleeper.app/v1
Docs:     https://docs.sleeper.com

You need your league_id (visible in the league URL on sleeper.com).
"""
from __future__ import annotations

from typing import Any

import requests

from ..scoring import ScoringConfig
from .base import FantasyPlatform, LeagueState, RosterSlot, Team

BASE = "https://api.sleeper.app/v1"

# Sleeper scoring_settings key  ->  our scoring.yaml rule (name, nflreadpy stat).
# Only the keys present in your league are imported; the rest use YAML defaults.
SLEEPER_MAP: dict[str, tuple[str, Any]] = {
    "pass_yd":  ("passing_yards",   "passing_yards"),
    "pass_td":  ("passing_td",      "passing_tds"),
    "pass_int": ("interception",    "passing_interceptions"),
    "pass_2pt": ("passing_2pt",     "passing_2pt_conversions"),
    "rush_yd":  ("rushing_yards",   "rushing_yards"),
    "rush_td":  ("rushing_td",      "rushing_tds"),
    "rush_2pt": ("rushing_2pt",     "rushing_2pt_conversions"),
    "rec":      ("receptions",      "receptions"),          # the PPR knob
    "rec_yd":   ("receiving_yards", "receiving_yards"),
    "rec_td":   ("receiving_td",    "receiving_tds"),
    "rec_2pt":  ("receiving_2pt",   "receiving_2pt_conversions"),
    "fum_lost": ("fumble_lost",
                 ["sack_fumbles_lost", "rushing_fumbles_lost", "receiving_fumbles_lost"]),
}


class SleeperPlatform(FantasyPlatform):
    platform_name = "sleeper"

    def __init__(self, league_id: str, season: int, timeout: int = 20):
        self.league_id = str(league_id)
        self.season = season
        self.timeout = timeout
        self._players_cache: dict[str, Any] | None = None

    def _get(self, path: str) -> Any:
        r = requests.get(f"{BASE}/{path}", timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    # -- core -------------------------------------------------------------
    def _league(self) -> dict[str, Any]:
        return self._get(f"league/{self.league_id}")

    def _players(self) -> dict[str, Any]:
        # Large (~5MB) — cache it. Maps sleeper player_id -> player metadata.
        if self._players_cache is None:
            self._players_cache = self._get("players/nfl")
        return self._players_cache

    def get_league_state(self) -> LeagueState:
        league = self._league()
        rosters = self._get(f"league/{self.league_id}/rosters")
        users = {u["user_id"]: u for u in self._get(f"league/{self.league_id}/users")}
        players = self._players()

        teams: list[Team] = []
        for r in rosters:
            owner = users.get(r.get("owner_id"), {})
            slots = []
            for pid in (r.get("players") or []):
                meta = players.get(str(pid), {})
                slots.append(RosterSlot(
                    player_id=str(pid),
                    name=meta.get("full_name"),
                    position=meta.get("position"),
                ))
            teams.append(Team(
                team_id=str(r.get("roster_id")),
                owner=owner.get("display_name"),
                roster=slots,
            ))

        return LeagueState(
            platform=self.platform_name,
            league_id=self.league_id,
            season=self.season,
            week=league.get("settings", {}).get("leg"),
            scoring_name=league.get("name", "sleeper league"),
            teams=teams,
            raw=league,
        )

    def get_free_agents(self) -> list[RosterSlot]:
        rosters = self._get(f"league/{self.league_id}/rosters")
        rostered = {str(p) for r in rosters for p in (r.get("players") or [])}
        players = self._players()
        fa = []
        for pid, meta in players.items():
            if pid not in rostered and meta.get("position") in {"QB", "RB", "WR", "TE", "K", "DEF"}:
                fa.append(RosterSlot(player_id=pid, name=meta.get("full_name"),
                                     position=meta.get("position")))
        return fa

    def trending(self, kind: str = "add", hours: int = 24, limit: int = 25) -> list[dict]:
        """Most-added or most-dropped players league-wide. Great waiver signal.

        kind: 'add' or 'drop'.
        """
        rows = self._get(f"players/nfl/trending/{kind}?lookback_hours={hours}&limit={limit}")
        players = self._players()
        for row in rows:
            meta = players.get(str(row.get("player_id")), {})
            row["name"] = meta.get("full_name")
            row["position"] = meta.get("position")
        return rows

    def import_scoring(self) -> ScoringConfig:
        ss = self._league().get("scoring_settings", {})
        rules: dict[str, Any] = {}
        for key, pts in ss.items():
            if key in SLEEPER_MAP and pts:
                rule_name, stat = SLEEPER_MAP[key]
                rules[rule_name] = {"stat": stat, "points": float(pts)}
        return ScoringConfig.from_dict({"name": "imported from Sleeper", "rules": rules})
