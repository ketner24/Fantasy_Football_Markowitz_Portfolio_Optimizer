"""
Common interface for fantasy platform connectors.

Both Sleeper and ESPN adapters implement this, so the rest of the app
(waiver logic, lineup optimizer) never needs to know which platform you're on.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from ..scoring import ScoringConfig


@dataclass
class RosterSlot:
    """One player on a team's roster."""
    player_id: str
    name: str | None = None
    position: str | None = None
    lineup_slot: str | None = None  # e.g. "RB", "FLEX", "BN"


@dataclass
class Team:
    team_id: str
    owner: str | None = None
    roster: list[RosterSlot] = field(default_factory=list)


@dataclass
class LeagueState:
    """A snapshot of a league at a point in time."""
    platform: str
    league_id: str
    season: int
    week: int | None
    scoring_name: str
    teams: list[Team] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)  # full platform payload


class FantasyPlatform(ABC):
    """Base connector. Subclasses talk to a specific platform's API."""

    platform_name: str = "base"

    @abstractmethod
    def get_league_state(self) -> LeagueState:
        """Rosters, teams, current week."""

    @abstractmethod
    def get_free_agents(self) -> list[RosterSlot]:
        """Players currently available to add."""

    @abstractmethod
    def import_scoring(self) -> ScoringConfig:
        """Read the league's actual scoring settings into a ScoringConfig.

        Lets you sync config/scoring.yaml to your real league instead of
        editing by hand. Call .save('config/scoring.yaml') on the result.
        """
