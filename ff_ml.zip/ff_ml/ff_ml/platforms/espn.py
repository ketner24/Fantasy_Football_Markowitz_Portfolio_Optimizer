"""
ESPN connector.  ESPN's fantasy API is undocumented but stable.

Public leagues:  no auth needed.
Private leagues: pass your `espn_s2` and `swid` cookies (grab them from your
                 browser while logged in to fantasy.espn.com). These are read
                 from your session only and never leave your machine.

Base (>= 2019 seasons):
  https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons/{year}/segments/0/leagues/{league_id}
"""
from __future__ import annotations

from typing import Any

import requests

from ..scoring import ScoringConfig
from .base import FantasyPlatform, LeagueState, RosterSlot, Team

BASE = "https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl"

# ESPN statId -> (rule name, nflreadpy stat). ESPN encodes scoring as statId+points.
ESPN_STAT_MAP: dict[int, tuple[str, Any]] = {
    3:  ("passing_yards",   "passing_yards"),
    4:  ("passing_td",      "passing_tds"),
    20: ("interception",    "passing_interceptions"),
    24: ("rushing_yards",   "rushing_yards"),
    25: ("rushing_td",      "rushing_tds"),
    42: ("receiving_yards", "receiving_yards"),
    43: ("receiving_td",    "receiving_tds"),
    53: ("receptions",      "receptions"),          # the PPR knob
    72: ("fumble_lost",
         ["sack_fumbles_lost", "rushing_fumbles_lost", "receiving_fumbles_lost"]),
}

# ESPN lineupSlotId -> label (offense-relevant subset)
SLOT_MAP = {0: "QB", 2: "RB", 4: "WR", 6: "TE", 16: "DST", 17: "K",
            23: "FLEX", 20: "BN", 21: "IR"}
POS_MAP = {1: "QB", 2: "RB", 3: "WR", 4: "TE", 5: "K", 16: "DST"}


class ESPNPlatform(FantasyPlatform):
    platform_name = "espn"

    def __init__(self, league_id: str | int, season: int,
                 espn_s2: str | None = None, swid: str | None = None,
                 timeout: int = 20):
        self.league_id = str(league_id)
        self.season = season
        self.timeout = timeout
        self.cookies = {}
        if espn_s2 and swid:
            self.cookies = {"espn_s2": espn_s2, "SWID": swid}

    def _get(self, views: list[str]) -> dict[str, Any]:
        url = f"{BASE}/seasons/{self.season}/segments/0/leagues/{self.league_id}"
        params = [("view", v) for v in views]
        r = requests.get(url, params=params, cookies=self.cookies, timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    def get_league_state(self) -> LeagueState:
        data = self._get(["mTeam", "mRoster", "mSettings"])
        teams: list[Team] = []
        for t in data.get("teams", []):
            slots = []
            for entry in t.get("roster", {}).get("entries", []):
                p = entry.get("playerPoolEntry", {}).get("player", {})
                slots.append(RosterSlot(
                    player_id=str(p.get("id")),
                    name=p.get("fullName"),
                    position=POS_MAP.get(p.get("defaultPositionId")),
                    lineup_slot=SLOT_MAP.get(entry.get("lineupSlotId")),
                ))
            teams.append(Team(
                team_id=str(t.get("id")),
                owner=t.get("name") or t.get("location"),
                roster=slots,
            ))
        settings = data.get("settings", {})
        return LeagueState(
            platform=self.platform_name,
            league_id=self.league_id,
            season=self.season,
            week=data.get("scoringPeriodId"),
            scoring_name=settings.get("name", "espn league"),
            teams=teams,
            raw=settings,
        )

    def get_free_agents(self, size: int = 200) -> list[RosterSlot]:
        # kona_player_info view + filter for FREEAGENT/WAIVERS status
        headers = {"X-Fantasy-Filter": (
            '{"players":{"filterStatus":{"value":["FREEAGENT","WAIVERS"]},'
            f'"limit":{size}}}}}')}
        url = f"{BASE}/seasons/{self.season}/segments/0/leagues/{self.league_id}"
        r = requests.get(url, params=[("view", "kona_player_info")],
                         headers=headers, cookies=self.cookies, timeout=self.timeout)
        r.raise_for_status()
        players = r.json().get("players", [])
        out = []
        for pe in players:
            p = pe.get("player", {})
            out.append(RosterSlot(player_id=str(p.get("id")), name=p.get("fullName"),
                                  position=POS_MAP.get(p.get("defaultPositionId"))))
        return out

    def import_scoring(self) -> ScoringConfig:
        data = self._get(["mSettings"])
        items = (data.get("settings", {})
                     .get("scoringSettings", {})
                     .get("scoringItems", []))
        rules: dict[str, Any] = {}
        for it in items:
            sid = it.get("statId")
            pts = it.get("points", 0.0)
            if sid in ESPN_STAT_MAP and pts:
                rule_name, stat = ESPN_STAT_MAP[sid]
                rules[rule_name] = {"stat": stat, "points": float(pts)}
        return ScoringConfig.from_dict({"name": "imported from ESPN", "rules": rules})
