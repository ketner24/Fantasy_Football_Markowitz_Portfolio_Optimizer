"""
Feature engineering + leakage-safe splitting.

The cardinal rule of fantasy modeling: to predict week t you may only use
information available *before* week t kicks off. Every feature here is built
from strictly prior weeks (lagged / rolling with a shift), and the split is
walk-forward, never random k-fold.
"""
from __future__ import annotations

from dataclasses import dataclass

import polars as pl

TARGET = "fantasy_points"


def build_features(
    pw: pl.DataFrame,
    roll_windows: tuple[int, ...] = (3, 5),
) -> pl.DataFrame:
    """Add lagged and rolling features per player, all shifted to avoid leakage.

    Produces, per player over time:
      - fp_lag1               : last week's points
      - fp_roll{w}_mean/std   : mean/std over the prior `w` games (excludes current)
      - fp_season_to_date     : cumulative average before this week
      - games_played_to_date  : experience proxy
    The target `fantasy_points` for week t is what we predict; features use < t.
    """
    pw = pw.sort(["player_id", "season", "week"])
    exprs: list[pl.Expr] = []

    # Last week's output (within player, across the whole history)
    exprs.append(pl.col(TARGET).shift(1).over("player_id").alias("fp_lag1"))

    # Rolling stats over PRIOR games: shift(1) first so the current game is excluded
    shifted = pl.col(TARGET).shift(1).over("player_id")
    for w in roll_windows:
        exprs.append(
            shifted.rolling_mean(window_size=w, min_samples=1)
                   .over("player_id").alias(f"fp_roll{w}_mean")
        )
        exprs.append(
            shifted.rolling_std(window_size=w, min_samples=2)
                   .over("player_id").alias(f"fp_roll{w}_std")
        )

    # Season-to-date average (expanding mean of prior games), and experience
    exprs.append(
        shifted.cum_sum().over("player_id") /
        pl.int_range(1, pl.len() + 1).over("player_id").cast(pl.Float64)
        .alias("_denominator") if False else
        (shifted.cum_sum().over("player_id") /
         pl.col(TARGET).shift(1).is_not_null().cast(pl.Int64)
         .cum_sum().over("player_id"))
        .alias("fp_season_to_date")
    )
    exprs.append(
        pl.col(TARGET).shift(1).is_not_null().cast(pl.Int64)
        .cum_sum().over("player_id").alias("games_played_to_date")
    )

    out = pw.with_columns(exprs)
    # First appearance of each player has no history -> drop rows with no lag1.
    return out.filter(pl.col("fp_lag1").is_not_null())


def feature_columns(df: pl.DataFrame) -> list[str]:
    """The engineered feature columns (everything starting fp_ or games_)."""
    return [c for c in df.columns
            if c.startswith(("fp_lag", "fp_roll", "fp_season", "games_"))]


@dataclass
class Split:
    train: pl.DataFrame
    test: pl.DataFrame
    label: str


def walk_forward_splits(
    df: pl.DataFrame,
    min_train_seasons: int = 2,
):
    """Yield expanding-window splits: train on all seasons < S, test on season S.

    This mimics reality — you only ever have the past to predict the future.
    Use these splits for every model you evaluate so results are comparable.
    """
    seasons = sorted(df.select("season").unique().to_series().to_list())
    for i in range(min_train_seasons, len(seasons)):
        test_season = seasons[i]
        train = df.filter(pl.col("season") < test_season)
        test = df.filter(pl.col("season") == test_season)
        yield Split(train=train, test=test, label=f"test={test_season}")


if __name__ == "__main__":
    from .historical import load_player_weeks
    pw = load_player_weeks([2021, 2022, 2023, 2024])
    feats = build_features(pw)
    print(f"Rows with features: {feats.height:,}")
    print("Feature columns:", feature_columns(feats))
    for sp in walk_forward_splits(feats):
        print(f"{sp.label}: train={sp.train.height:,}  test={sp.test.height:,}")
