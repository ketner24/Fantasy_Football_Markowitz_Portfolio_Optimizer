"""
Historical data pipeline.

Pulls weekly player stats from nflreadpy (the maintained successor to
nfl_data_py), applies your scoring config, and returns a tidy player-week
table that is the base for feature engineering and model training.
"""
from __future__ import annotations

import nflreadpy as nfl
import polars as pl

from ..scoring import ScoringConfig, compute_fantasy_points

FANTASY_POSITIONS = {"QB", "RB", "WR", "TE"}
ID_COLS = ["player_id", "player_display_name", "position", "team",
           "opponent_team", "season", "week"]


def load_player_weeks(
    seasons: list[int],
    scoring: ScoringConfig | None = None,
    positions: set[str] | None = None,
) -> pl.DataFrame:
    """Return one row per player per week, with a `fantasy_points` column.

    seasons   : e.g. list(range(2015, 2025))
    scoring   : ScoringConfig; defaults to config/scoring.yaml (PPR)
    positions : restrict to these positions (default QB/RB/WR/TE)
    """
    scoring = scoring or ScoringConfig.load()
    positions = positions or FANTASY_POSITIONS

    df = nfl.load_player_stats(seasons=seasons)
    df = df.filter(
        (pl.col("season_type") == "REG") & (pl.col("position").is_in(list(positions)))
    )
    df = compute_fantasy_points(df, scoring)

    keep = [c for c in ID_COLS if c in df.columns]
    keep += sorted(scoring.required_columns() & set(df.columns))
    keep += ["fantasy_points"]
    return df.select(pl.col(keep).unique(subset=None) if False else keep).sort(
        ["season", "week", "player_id"]
    )


if __name__ == "__main__":
    scoring = ScoringConfig.load()
    pw = load_player_weeks([2023, 2024], scoring)
    print(f"Scoring: {scoring.name}")
    print(f"Player-weeks: {pw.height:,} rows, {pw.width} cols")
    top = (pw.group_by("player_display_name")
             .agg(pl.col("fantasy_points").sum().alias("total"))
             .sort("total", descending=True)
             .head(10))
    print(top)
