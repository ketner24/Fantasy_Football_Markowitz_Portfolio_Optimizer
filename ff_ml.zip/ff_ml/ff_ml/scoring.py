"""
Config-driven fantasy scoring engine.

Everything reads from config/scoring.yaml. Change the YAML and re-run — no code
edits needed. This is the single source of truth for "what is a fantasy point"
across the whole project (historical labels, projections, optimizer objective).
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import polars as pl
import yaml

DEFAULT_CONFIG = Path(__file__).resolve().parents[1] / "config" / "scoring.yaml"


@dataclass
class ScoringConfig:
    """Parsed, validated scoring rules loaded from a YAML file."""

    name: str
    rules: dict[str, dict[str, Any]]
    bonuses: list[dict[str, Any]] = field(default_factory=list)
    source_path: Path | None = None

    @classmethod
    def load(cls, path: str | Path | None = None) -> "ScoringConfig":
        path = Path(path) if path else DEFAULT_CONFIG
        with open(path) as f:
            raw = yaml.safe_load(f)
        return cls(
            name=raw.get("name", "unnamed"),
            rules=raw.get("rules", {}),
            bonuses=raw.get("bonuses") or [],
            source_path=path,
        )

    @classmethod
    def from_dict(cls, d: dict[str, Any], name: str = "imported") -> "ScoringConfig":
        """Build a config directly (used by platform scoring-settings importers)."""
        return cls(name=d.get("name", name), rules=d.get("rules", {}),
                   bonuses=d.get("bonuses") or [])

    def save(self, path: str | Path) -> None:
        """Write this config back out to YAML (e.g. after importing from ESPN)."""
        payload = {"name": self.name, "rules": self.rules, "bonuses": self.bonuses}
        with open(path, "w") as f:
            yaml.safe_dump(payload, f, sort_keys=False, default_flow_style=False)

    # -- helpers ------------------------------------------------------------
    @staticmethod
    def _stat_cols(spec: dict[str, Any]) -> list[str]:
        stat = spec["stat"]
        return [stat] if isinstance(stat, str) else list(stat)

    def required_columns(self) -> set[str]:
        cols: set[str] = set()
        for spec in self.rules.values():
            cols.update(self._stat_cols(spec))
        for b in self.bonuses:
            cols.add(b["stat"])
        return cols


def compute_fantasy_points(
    df: pl.DataFrame,
    config: ScoringConfig,
    out_col: str = "fantasy_points",
) -> pl.DataFrame:
    """
    Add a fantasy-points column to a player-week stats DataFrame.

    Missing stat columns are treated as 0 (with a warning) so a scoring rule
    that references a column absent from a given season won't crash the run.
    """
    available = set(df.columns)
    terms: list[pl.Expr] = []

    def col_or_zero(name: str) -> pl.Expr:
        if name in available:
            return pl.col(name).fill_null(0.0).cast(pl.Float64)
        warnings.warn(f"scoring: column '{name}' not in data; treating as 0")
        return pl.lit(0.0)

    # Base rules
    for rule_name, spec in config.rules.items():
        stat_expr = sum((col_or_zero(c) for c in ScoringConfig._stat_cols(spec)),
                        start=pl.lit(0.0))
        terms.append((stat_expr * float(spec["points"])).alias(f"_pts_{rule_name}"))

    # Threshold bonuses (fire once per game when stat >= threshold)
    for i, b in enumerate(config.bonuses):
        hit = (col_or_zero(b["stat"]) >= float(b["threshold"])).cast(pl.Float64)
        terms.append((hit * float(b["points"])).alias(f"_bonus_{i}"))

    scored = df.with_columns(terms)
    pts_cols = [c for c in scored.columns if c.startswith(("_pts_", "_bonus_"))]
    scored = scored.with_columns(
        sum((pl.col(c) for c in pts_cols), start=pl.lit(0.0)).alias(out_col)
    ).drop(pts_cols)
    return scored


if __name__ == "__main__":
    cfg = ScoringConfig.load()
    print(f"Loaded scoring: {cfg.name}")
    print(f"Rules: {list(cfg.rules)}")
    print(f"Columns needed: {sorted(cfg.required_columns())}")
