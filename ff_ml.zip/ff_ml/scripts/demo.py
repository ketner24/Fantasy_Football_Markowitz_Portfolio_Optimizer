"""
End-to-end demo. Run from the project root:

    python -m scripts.demo

Shows: load scoring -> pull real historical data -> apply PPR -> build
leakage-safe features -> produce walk-forward splits ready for modeling.
"""
import polars as pl

from ff_ml.scoring import ScoringConfig
from ff_ml.data.historical import load_player_weeks
from ff_ml.data.features import build_features, feature_columns, walk_forward_splits

SEASONS = [2021, 2022, 2023, 2024]


def main():
    scoring = ScoringConfig.load()               # edit config/scoring.yaml to change
    print(f"[1] Scoring loaded: {scoring.name}")

    pw = load_player_weeks(SEASONS, scoring)
    print(f"[2] Player-weeks pulled: {pw.height:,} rows over seasons {SEASONS}")

    feats = build_features(pw)
    print(f"[3] Features built: {feats.height:,} rows, "
          f"{len(feature_columns(feats))} features -> {feature_columns(feats)}")

    print("[4] Walk-forward splits (train on the past, test on the next season):")
    for sp in walk_forward_splits(feats):
        print(f"      {sp.label}:  train={sp.train.height:,}  test={sp.test.height:,}")

    # Peek: the feature matrix a model would consume
    X_cols = feature_columns(feats)
    sample = feats.filter(pl.col("season") == 2024).select(
        ["player_display_name", "position", "week", *X_cols, "fantasy_points"]
    ).head(5)
    print("\n[5] Sample model-ready rows (features + target):")
    print(sample)


if __name__ == "__main__":
    main()
